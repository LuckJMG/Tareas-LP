Nombre: Lucas Joaquin Mosquera Gaete
ROL: 202273504-k

=== Compilacion y Ejecucion ===

- Para compilar ocupe el comando `make` dentro del proyecto
- Para ejecutar el juego puede usar `make run` estando en el proyecto
- Si no sirve el comando anterior, pruebe con `java Juego`

===============================

=== Especificaciones ===

- Compilado con javac 11.0.20 y con OpenJDK 11.0.2
- make version 4.4.1

========================

P.D.: Hay 6 finales en total!!! Los 3 que dice la tarea y 3 secretos extra. 
		Una pista, hay por lo menos uno relacionado por cada segmento de la 
		pantalla final.

