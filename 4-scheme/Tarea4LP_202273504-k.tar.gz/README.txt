Nombre: Lucas Joaquín Mosquera Gaete
ROL: 202273504-k

- Los archivos están ordenados como fue especificado en el pdf de la tarea.
- Cada pregunta tiene su propio archivo con la implementación de lo especificado.
- Todas las funciones están comentadas para aclarar que hace cada una.
- Hecho en DrRacket 8.10

