Nombre: Lucas Joaquín Mosquera Gaete
ROL: 202273504-k

- Los archivos están ordenados como fue especificado en el pdf de la tarea.
- Cada pregunta tiene su propio archivo con la implementación de lo especificado.
- Cada relación esta comentada para explicar que hace cada una y que hacen sus parámetros.
- Se ocupó SWI-prolog version 9.0.4